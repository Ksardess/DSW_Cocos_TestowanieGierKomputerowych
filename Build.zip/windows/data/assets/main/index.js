System.register("chunks:///_virtual/HelloWorldOnSpace.ts",["cc"],(function(e){var o,n,t,c,l,s;return{setters:[function(e){o=e.cclegacy,n=e.Component,t=e.systemEvent,c=e.SystemEvent,l=e.KeyCode,s=e._decorator}],execute:function(){var r;o._RF.push({},"48cb2Ybxf1Hm6Dua2Ivt/zl","HelloWorldOnSpace",void 0);const{ccclass:a,property:y}=s;e("HelloWorldOnSpace",a("HelloWorldOnSpace")(r=class extends n{onLoad(){t.on(c.EventType.KEY_DOWN,this.onKeyDown,this)}onDestroy(){t.off(c.EventType.KEY_DOWN,this.onKeyDown,this)}onKeyDown(e){e.keyCode===l.SPACE&&console.log("HelloWorld")}})||r);o._RF.pop()}}}));

System.register("chunks:///_virtual/main",["./HelloWorldOnSpace.ts"],(function(){return{setters:[null],execute:function(){}}}));

(function(r) {
  r('virtual:///prerequisite-imports/main', 'chunks:///_virtual/main'); 
})(function(mid, cid) {
    System.register(mid, [cid], function (_export, _context) {
    return {
        setters: [function(_m) {
            var _exportObj = {};

            for (var _key in _m) {
              if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
            }
      
            _export(_exportObj);
        }],
        execute: function () { }
    };
    });
});